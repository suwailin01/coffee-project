<body style="background-color:#ffa065bd;">
<div>
    <br>
      <center>
      <img src="images/thank.png" width="600"/><br><br><br>
     
     <a href="index.html"> <img src="images/home.png" width="100"/></a>
      <br>
      </center>
       </div>
</body>
      
