-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 30, 2024 at 03:44 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `coffeedb`
--

-- --------------------------------------------------------

--
-- Table structure for table `beanlist`
--

CREATE TABLE `beanlist` (
  `ID` int(11) NOT NULL,
  `Name` varchar(200) NOT NULL,
  `Price` int(20) NOT NULL,
  `Description` varchar(500) NOT NULL,
  `img` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `beanlist`
--

INSERT INTO `beanlist` (`ID`, `Name`, `Price`, `Description`, `img`) VALUES
(9, 'Shan bean', 40000, 'The best bean made in Myanmar', 'under3.jpg'),
(10, 'Korea bean', 80000, 'good', 'under4.jpeg'),
(11, 'Asia bean', 100000, 'Fresh beans have a firm texture, while older beans might feel a bit brittle or crumbly.', 'beanbox1.jpg'),
(12, 'C.B Bean', 90000, 'Freshly roasted dark beans can feel warm and slightly oily, indicating their freshness. If they feel dry or crumbly, they may be stale.', 'beanbox2.webp'),
(13, 'ORO', 205000, 'Oro Coffee is known for its rich flavor and premium quality, often sourced from high-altitude regions to ensure optimal taste. ', 'beanbox3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `ID` int(40) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(300) NOT NULL,
  `Message` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`ID`, `Name`, `Email`, `Message`) VALUES
(1, 'KoKo', 'yuwakoko9898@gmail.com', 'dsaijsi shdsdhsdsdsd dsdssdds'),
(2, 'KoKo', 'yuwakoko9898@gmail.com', 'dsaijsi shdsdhsdsdsd dsdssdds'),
(3, 'KoKo', 'yuwakoko9898@gmail.com', 'dsaijsi shdsdhsdsdsd dsdssdds'),
(4, 'MgMg', 'yuwakoko9898@gmail.com', 'very good service'),
(5, 'su wai', 'mwwdnetwork@gmail.com', 'goood'),
(6, 'wow', 'suwailin001@gmail.com', 'good '),
(7, 'Kaung Myat', 'km.hein001@gmail.com', 'i like coffee. and i can make coffee from bean.'),
(8, 'Wai Lin', 'wai2211lin@gmail.com', 'good wow i always buy'),
(9, 'Lin', 'lin2211lin@gmail.com', 'good and smell good'),
(10, 'Lin', 'lin2211lin@gmail.com', 'good and smell good'),
(11, 'Lin', 'lin2211lin@gmail.com', 'good idea'),
(12, 'Lin', 'lin2211lin@gmail.com', 'good idea'),
(13, 'su wai', 'wailin0011@gmail.com', 'good'),
(14, 'su wai', 'wailin0011@gmail.com', 'good'),
(15, 'Tun Tun', 'tuntun2211@gmail.com', 'i love coffee'),
(16, 'Tun', 'tuntun2211@gmail.com', 'My dad want to buy bean');

-- --------------------------------------------------------

--
-- Table structure for table `drinklist`
--

CREATE TABLE `drinklist` (
  `ID` int(100) NOT NULL,
  `Name` varchar(300) NOT NULL,
  `Price` int(100) NOT NULL,
  `Description` varchar(500) NOT NULL,
  `img` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `drinklist`
--

INSERT INTO `drinklist` (`ID`, `Name`, `Price`, `Description`, `img`) VALUES
(6, 'Cold Coffee', 5000, '0.5', 'under1.jpg'),
(7, 'Cold Latte', 4500, 'good', 'cold latte.jpg'),
(8, 'Cappuccino', 4500, 'chocolate twist on the classic with cocoa powder.', 'coffee1.webp'),
(9, 'Sweet Tea', 4300, 'Drinking tea often evokes feelings of relaxation.', 'coffee3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `ID` int(100) NOT NULL,
  `Name` varchar(200) NOT NULL,
  `Phone` varchar(200) NOT NULL,
  `Address` varchar(1100) NOT NULL,
  `P_name` varchar(100) NOT NULL,
  `Price` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`ID`, `Name`, `Phone`, `Address`, `P_name`, `Price`) VALUES
(5, 'MgMg', '0923323223', 'dasbkdskdssddsa', 'Burger', 3000),
(8, 'John Doe', '123456789', '123 Main St', 'Coffee', 5),
(9, 'Wai Lin', '095033433', 'idhf adihioasdhf iadhnfmcxkhv mJKDHo;j alsz', 'Shan bean', 40000),
(10, 'KMH', '095033432', 'idhf adihioasdhf iadhnfmcxkhv mJKDHo;j alsz', 'Shan bean', 40000),
(11, 'Ji', '09254022688', 'eafklhf aif aeiodfhaoi wegaedfh oiaef ', 'Cold Coffee', 5000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `beanlist`
--
ALTER TABLE `beanlist`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `drinklist`
--
ALTER TABLE `drinklist`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `beanlist`
--
ALTER TABLE `beanlist`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `ID` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `drinklist`
--
ALTER TABLE `drinklist`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
