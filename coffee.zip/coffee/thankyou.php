<body style="background-color:#ffa065bd;">
<div>
    <br>
      <center>
     <div><img src="images/thank.png" width="600"/><br></div> 
     <div><img src="images/contact.gif" width="400"/></div>
     <a href="index.html"> <img src="images/home.png" width="100"/></a>
      <br>
      </center>
       </div>
</body>
      
