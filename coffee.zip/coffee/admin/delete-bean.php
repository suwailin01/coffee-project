<?php
include("connection.php"); 
$q = "delete from beanlist where id='{$_GET['id']}'";
$con->query($q); //delet from db
unlink("img/".$_GET['img']); //image delec\te
header('location:bean.php'); //return bean.php
?>
